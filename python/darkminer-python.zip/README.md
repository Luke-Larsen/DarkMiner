# DarkMiner
 A program to use idle computer time to mine crypto
# This code is written in python
 It currently holds support for Windows and Linux 64bit machines
# Dependencies
    ** Windows: **
        Python3
    ** Linux: **
        Python3
        easygui 
            On ubuntu install using sudo apt-get install python3-easygui (Pip doesn't work)
        https://github.com/g0hl1n/xprintidle

# How To Start/Install
Download all the files here and run the main.py file with python3.
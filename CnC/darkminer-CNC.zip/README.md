# DarkMiner
## This is the web script for command and control
 This is mainly useful when you want to see if your machines are working and mining on pools or little statistics on how they are doing or total times.
 There will be some features for removing users if you no longer want them mining on your machines.
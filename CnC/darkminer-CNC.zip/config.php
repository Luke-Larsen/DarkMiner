<?php
$con = new mysqli("dbHost", "dbUsername", "dbPassword", "dbDatabaseName");
//Google Recaptcha
$googleCaptchaSecret = "";
$googleCaptchaPublic = "";